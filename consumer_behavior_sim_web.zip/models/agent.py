"""
消費者行為模擬系統 - 生成式代理模組
基於"Generative Agents: Interactive Simulacra of Human Behavior"論文實現的代理架構
"""

import os
import json
import logging
import uuid
import numpy as np
import datetime
import random
from collections import deque

# 設置日誌
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class Memory:
    """記憶系統，管理代理的記憶"""
    
    def __init__(self, capacity=1000):
        """初始化記憶系統
        
        Args:
            capacity: 記憶容量
        """
        self.memories = []
        self.capacity = capacity
    
    def add(self, content, importance=0.5, source="observation", related_memories=None):
        """添加記憶
        
        Args:
            content: 記憶內容
            importance: 重要性 (0-1)
            source: 記憶來源
            related_memories: 相關記憶ID列表
            
        Returns:
            記憶ID
        """
        memory_id = str(uuid.uuid4())
        timestamp = datetime.datetime.now().isoformat()
        
        memory = {
            "id": memory_id,
            "content": content,
            "importance": importance,
            "timestamp": timestamp,
            "source": source,
            "related_memories": related_memories or [],
            "last_accessed": timestamp,
            "access_count": 0
        }
        
        self.memories.append(memory)
        
        # 如果超過容量，移除最不重要的記憶
        if len(self.memories) > self.capacity:
            self.memories.sort(key=lambda x: x["importance"])
            self.memories.pop(0)
        
        return memory_id
    
    def get(self, memory_id):
        """獲取特定記憶
        
        Args:
            memory_id: 記憶ID
            
        Returns:
            記憶
        """
        for memory in self.memories:
            if memory["id"] == memory_id:
                # 更新訪問時間和次數
                memory["last_accessed"] = datetime.datetime.now().isoformat()
                memory["access_count"] += 1
                return memory
        
        return None
    
    def search(self, query, limit=10):
        """搜索記憶
        
        Args:
            query: 搜索關鍵詞
            limit: 返回結果數量限制
            
        Returns:
            匹配的記憶列表
        """
        results = []
        
        for memory in self.memories:
            if query.lower() in memory["content"].lower():
                # 更新訪問時間和次數
                memory["last_accessed"] = datetime.datetime.now().isoformat()
                memory["access_count"] += 1
                results.append(memory)
        
        # 按重要性排序
        results.sort(key=lambda x: x["importance"], reverse=True)
        
        return results[:limit]
    
    def get_recent(self, limit=10):
        """獲取最近的記憶
        
        Args:
            limit: 返回結果數量限制
            
        Returns:
            最近的記憶列表
        """
        # 按時間戳排序
        recent = sorted(self.memories, key=lambda x: x["timestamp"], reverse=True)
        
        return recent[:limit]
    
    def get_important(self, limit=10):
        """獲取最重要的記憶
        
        Args:
            limit: 返回結果數量限制
            
        Returns:
            最重要的記憶列表
        """
        # 按重要性排序
        important = sorted(self.memories, key=lambda x: x["importance"], reverse=True)
        
        return important[:limit]
    
    def update_importance(self, memory_id, importance):
        """更新記憶重要性
        
        Args:
            memory_id: 記憶ID
            importance: 新的重要性值
            
        Returns:
            是否更新成功
        """
        for memory in self.memories:
            if memory["id"] == memory_id:
                memory["importance"] = importance
                return True
        
        return False
    
    def forget(self, memory_id):
        """刪除記憶
        
        Args:
            memory_id: 記憶ID
            
        Returns:
            是否刪除成功
        """
        for i, memory in enumerate(self.memories):
            if memory["id"] == memory_id:
                self.memories.pop(i)
                return True
        
        return False
    
    def decay(self, rate=0.01):
        """記憶衰減
        
        Args:
            rate: 衰減率
        """
        now = datetime.datetime.now()
        
        for memory in self.memories:
            # 計算時間差（天）
            created = datetime.datetime.fromisoformat(memory["timestamp"])
            days_passed = (now - created).days
            
            # 根據時間和訪問次數計算衰減
            decay_factor = rate * days_passed / (memory["access_count"] + 1)
            
            # 應用衰減
            memory["importance"] = max(0.1, memory["importance"] - decay_factor)
    
    def save(self, path):
        """保存記憶到文件
        
        Args:
            path: 文件路徑
            
        Returns:
            是否保存成功
        """
        try:
            with open(path, 'w', encoding='utf-8') as f:
                json.dump(self.memories, f, ensure_ascii=False, indent=2)
            return True
        except Exception as e:
            logger.error(f"保存記憶失敗: {str(e)}")
            return False
    
    def load(self, path):
        """從文件加載記憶
        
        Args:
            path: 文件路徑
            
        Returns:
            是否加載成功
        """
        try:
            if os.path.exists(path):
                with open(path, 'r', encoding='utf-8') as f:
                    self.memories = json.load(f)
                return True
            return False
        except Exception as e:
            logger.error(f"加載記憶失敗: {str(e)}")
            return False


class Reflection:
    """反思機制，對記憶進行反思，形成更高層次的見解"""
    
    def __init__(self, memory):
        """初始化反思機制
        
        Args:
            memory: 記憶系統
        """
        self.memory = memory
        self.insights = []
    
    def reflect(self, trigger="periodic", related_memories=None):
        """進行反思
        
        Args:
            trigger: 觸發反思的原因
            related_memories: 相關記憶ID列表
            
        Returns:
            反思結果
        """
        # 獲取相關記憶
        memories_to_reflect = []
        
        if related_memories:
            for memory_id in related_memories:
                memory = self.memory.get(memory_id)
                if memory:
                    memories_to_reflect.append(memory)
        else:
            # 使用最近和最重要的記憶
            memories_to_reflect = self.memory.get_recent(5) + self.memory.get_important(5)
        
        if not memories_to_reflect:
            return None
        
        # 提取記憶內容
        memory_contents = [m["content"] for m in memories_to_reflect]
        
        # 生成反思內容（這裡使用簡單的模擬）
        insight = self._generate_insight(memory_contents, trigger)
        
        # 保存反思結果
        insight_id = str(uuid.uuid4())
        timestamp = datetime.datetime.now().isoformat()
        
        insight_obj = {
            "id": insight_id,
            "content": insight,
            "timestamp": timestamp,
            "trigger": trigger,
            "related_memories": [m["id"] for m in memories_to_reflect]
        }
        
        self.insights.append(insight_obj)
        
        # 將反思結果添加到記憶中
        self.memory.add(
            content=f"反思: {insight}",
            importance=0.8,
            source="reflection",
            related_memories=[m["id"] for m in memories_to_reflect]
        )
        
        return insight_obj
    
    def _generate_insight(self, memory_contents, trigger):
        """生成反思內容
        
        Args:
            memory_contents: 記憶內容列表
            trigger: 觸發反思的原因
            
        Returns:
            反思內容
        """
        # 在實際應用中，這裡應該使用更複雜的邏輯或LLM
        # 這裡使用簡單的模擬
        
        if not memory_contents:
            return "沒有足夠的記憶可供反思。"
        
        # 簡單的模板
        templates = [
            "基於過去的經驗，我注意到{}。",
            "我發現自己對{}有特別的興趣。",
            "我似乎傾向於{}。",
            "我對{}的看法可能受到了{}的影響。",
            "我認為{}是重要的，因為{}。"
        ]
        
        # 從記憶中提取關鍵詞
        all_words = " ".join(memory_contents).lower().split()
        common_words = ["我", "的", "是", "在", "有", "和", "了", "不", "這", "他", "她", "它", "們", "個", "為", "與"]
        keywords = [w for w in all_words if len(w) > 1 and w not in common_words]
        
        if not keywords:
            return "我需要更多經驗來形成有意義的見解。"
        
        # 隨機選擇模板和關鍵詞
        template = random.choice(templates)
        
        if "{}" in template:
            if template.count("{}") == 1:
                return template.format(random.choice(keywords))
            else:
                return template.format(random.choice(keywords), random.choice(keywords))
        
        return template
    
    def get_recent_insights(self, limit=5):
        """獲取最近的反思
        
        Args:
            limit: 返回結果數量限制
            
        Returns:
            最近的反思列表
        """
        # 按時間戳排序
        recent = sorted(self.insights, key=lambda x: x["timestamp"], reverse=True)
        
        return recent[:limit]
    
    def save(self, path):
        """保存反思到文件
        
        Args:
            path: 文件路徑
            
        Returns:
            是否保存成功
        """
        try:
            with open(path, 'w', encoding='utf-8') as f:
                json.dump(self.insights, f, ensure_ascii=False, indent=2)
            return True
        except Exception as e:
            logger.error(f"保存反思失敗: {str(e)}")
            return False
    
    def load(self, path):
        """從文件加載反思
        
        Args:
            path: 文件路徑
            
        Returns:
            是否加載成功
        """
        try:
            if os.path.exists(path):
                with open(path, 'r', encoding='utf-8') as f:
                    self.insights = json.load(f)
                return True
            return False
        except Exception as e:
            logger.error(f"加載反思失敗: {str(e)}")
            return False


class Planning:
    """規劃能力，設定目標並生成實現目標的計劃"""
    
    def __init__(self, memory, reflection):
        """初始化規劃能力
        
        Args:
            memory: 記憶系統
            reflection: 反思機制
        """
        self.memory = memory
        self.reflection = reflection
        self.goals = []
        self.plans = []
        self.current_plan = None
    
    def set_goal(self, goal, importance=0.7, deadline=None):
        """設定目標
        
        Args:
            goal: 目標內容
            importance: 重要性 (0-1)
            deadline: 截止日期
            
        Returns:
            目標ID
        """
        goal_id = str(uuid.uuid4())
        timestamp = datetime.datetime.now().isoformat()
        
        goal_obj = {
            "id": goal_id,
            "content": goal,
            "importance": importance,
            "timestamp": timestamp,
            "deadline": deadline,
            "status": "active"
        }
        
        self.goals.append(goal_obj)
        
        # 將目標添加到記憶中
        self.memory.add(
            content=f"設定目標: {goal}",
            importance=importance,
            source="planning"
        )
        
        return goal_id
    
    def create_plan(self, goal_id):
        """為目標創建計劃
        
        Args:
            goal_id: 目標ID
            
        Returns:
            計劃ID
        """
        # 查找目標
        goal = None
        for g in self.goals:
            if g["id"] == goal_id:
                goal = g
                break
        
        if not goal:
            return None
        
        # 獲取相關記憶和反思
        related_memories = self.memory.search(goal["content"], limit=5)
        recent_insights = self.reflection.get_recent_insights(limit=3)
        
        # 生成計劃（這裡使用簡單的模擬）
        plan_content = self._generate_plan(goal["content"], related_memories, recent_insights)
        
        plan_id = str(uuid.uuid4())
        timestamp = datetime.datetime.now().isoformat()
        
        plan_obj = {
            "id": plan_id,
            "goal_id": goal_id,
            "content": plan_content,
            "timestamp": timestamp,
            "status": "created",
            "steps": [],
            "current_step": 0
        }
        
        # 生成計劃步驟
        steps = self._generate_steps(goal["content"], plan_content)
        plan_obj["steps"] = steps
        
        self.plans.append(plan_obj)
        
        # 將計劃添加到記憶中
        self.memory.add(
            content=f"創建計劃: {plan_content}",
            importance=goal["importance"],
            source="planning",
            related_memories=[m["id"] for m in related_memories]
        )
        
        return plan_id
    
    def _generate_plan(self, goal, related_memories, recent_insights):
        """生成計劃內容
        
        Args:
            goal: 目標內容
            related_memories: 相關記憶列表
            recent_insights: 最近的反思列表
            
        Returns:
            計劃內容
        """
        # 在實際應用中，這裡應該使用更複雜的邏輯或LLM
        # 這裡使用簡單的模擬
        
        # 簡單的模板
        templates = [
            f"為了{goal}，我需要制定一個系統性的計劃。",
            f"我計劃通過以下步驟實現{goal}。",
            f"為了達成{goal}，我將採取一系列行動。"
        ]
        
        return random.choice(templates)
    
    def _generate_steps(self, goal, plan):
        """生成計劃步驟
        
        Args:
            goal: 目標內容
            plan: 計劃內容
            
        Returns:
            計劃步驟列表
        """
        # 在實際應用中，這裡應該使用更複雜的邏輯或LLM
        # 這裡使用簡單的模擬
        
        # 根據目標類型生成不同的步驟
        if "購買" in goal or "買" in goal:
            steps = [
                {"id": str(uuid.uuid4()), "content": "研究產品信息和評價", "status": "pending"},
                {"id": str(uuid.uuid4()), "content": "比較不同選項的價格和特性", "status": "pending"},
                {"id": str(uuid.uuid4()), "content": "確定預算和購買時間", "status": "pending"},
                {"id": str(uuid.uuid4()), "content": "做出購買決定", "status": "pending"}
            ]
        elif "學習" in goal or "研究" in goal:
            steps = [
                {"id": str(uuid.uuid4()), "content": "收集相關資料和資源", "status": "pending"},
                {"id": str(uuid.uuid4()), "content": "制定學習計劃和時間表", "status": "pending"},
                {"id": str(uuid.uuid4()), "content": "深入學習核心概念", "status": "pending"},
                {"id": str(uuid.uuid4()), "content": "實踐和應用所學知識", "status": "pending"},
                {"id": str(uuid.uuid4()), "content": "評估學習成果", "status": "pending"}
            ]
        else:
            # 通用步驟
            steps = [
                {"id": str(uuid.uuid4()), "content": "收集相關信息", "status": "pending"},
                {"id": str(uuid.uuid4()), "content": "分析可行的方法", "status": "pending"},
                {"id": str(uuid.uuid4()), "content": "選擇最佳方案", "status": "pending"},
                {"id": str(uuid.uuid4()), "content": "執行計劃", "status": "pending"},
                {"id": str(uuid.uuid4()), "content": "評估結果", "status": "pending"}
            ]
        
        return steps
    
    def get_active_goals(self):
        """獲取活躍的目標
        
        Returns:
            活躍的目標列表
        """
        return [g for g in self.goals if g["status"] == "active"]
    
    def get_plan(self, plan_id):
        """獲取特定計劃
        
        Args:
            plan_id: 計劃ID
            
        Returns:
            計劃
        """
        for plan in self.plans:
            if plan["id"] == plan_id:
                return plan
        
        return None
    
    def update_plan_status(self, plan_id, status):
        """更新計劃狀態
        
        Args:
            plan_id: 計劃ID
            status: 新狀態
            
        Returns:
            是否更新成功
        """
        for plan in self.plans:
            if plan["id"] == plan_id:
                plan["status"] = status
                return True
        
        return False
    
    def update_step_status(self, plan_id, step_id, status):
        """更新計劃步驟狀態
        
        Args:
            plan_id: 計劃ID
            step_id: 步驟ID
            status: 新狀態
            
        Returns:
            是否更新成功
        """
        for plan in self.plans:
            if plan["id"] == plan_id:
                for step in plan["steps"]:
                    if step["id"] == step_id:
                        step["status"] = status
                        return True
        
        return False
    
    def advance_plan(self, plan_id):
        """推進計劃到下一步
        
        Args:
            plan_id: 計劃ID
            
        Returns:
            是否推進成功
        """
        for plan in self.plans:
            if plan["id"] == plan_id:
                if plan["current_step"] < len(plan["steps"]):
                    # 將當前步驟標記為完成
                    if plan["current_step"] > 0:
                        plan["steps"][plan["current_step"] - 1]["status"] = "completed"
                    
                    # 推進到下一步
                    plan["current_step"] += 1
                    
                    # 如果已完成所有步驟
                    if plan["current_step"] >= len(plan["steps"]):
                        plan["status"] = "completed"
                        
                        # 更新相關目標
                        for goal in self.goals:
                            if goal["id"] == plan["goal_id"]:
                                goal["status"] = "completed"
                                break
                    
                    return True
        
        return False
    
    def save(self, path):
        """保存規劃到文件
        
        Args:
            path: 文件路徑
            
        Returns:
            是否保存成功
        """
        try:
            data = {
                "goals": self.goals,
                "plans": self.plans,
                "current_plan": self.current_plan
            }
            
            with open(path, 'w', encoding='utf-8') as f:
                json.dump(data, f, ensure_ascii=False, indent=2)
            return True
        except Exception as e:
            logger.error(f"保存規劃失敗: {str(e)}")
            return False
    
    def load(self, path):
        """從文件加載規劃
        
        Args:
            path: 文件路徑
            
        Returns:
            是否加載成功
        """
        try:
            if os.path.exists(path):
                with open(path, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                    
                    self.goals = data.get("goals", [])
                    self.plans = data.get("plans", [])
                    self.current_plan = data.get("current_plan")
                return True
            return False
        except Exception as e:
            logger.error(f"加載規劃失敗: {str(e)}")
            return False


class Interaction:
    """互動能力，與其他代理和用戶進行對話互動"""
    
    def __init__(self, memory, reflection, planning):
        """初始化互動能力
        
        Args:
            memory: 記憶系統
            reflection: 反思機制
            planning: 規劃能力
        """
        self.memory = memory
        self.reflection = reflection
        self.planning = planning
        self.conversation_history = []
    
    def receive_message(self, sender, message):
        """接收消息
        
        Args:
            sender: 發送者
            message: 消息內容
            
        Returns:
            回覆消息
        """
        # 記錄消息
        timestamp = datetime.datetime.now().isoformat()
        
        message_obj = {
            "sender": sender,
            "content": message,
            "timestamp": timestamp
        }
        
        self.conversation_history.append(message_obj)
        
        # 將消息添加到記憶中
        self.memory.add(
            content=f"{sender}說: {message}",
            importance=0.6,
            source="conversation"
        )
        
        # 生成回覆
        reply = self._generate_reply(sender, message)
        
        # 記錄回覆
        reply_obj = {
            "sender": "agent",
            "content": reply,
            "timestamp": datetime.datetime.now().isoformat()
        }
        
        self.conversation_history.append(reply_obj)
        
        # 將回覆添加到記憶中
        self.memory.add(
            content=f"我回覆{sender}: {reply}",
            importance=0.6,
            source="conversation"
        )
        
        # 觸發反思
        if len(self.conversation_history) % 5 == 0:
            self.reflection.reflect(trigger="conversation")
        
        return reply
    
    def _generate_reply(self, sender, message):
        """生成回覆
        
        Args:
            sender: 發送者
            message: 消息內容
            
        Returns:
            回覆消息
        """
        # 在實際應用中，這裡應該使用更複雜的邏輯或LLM
        # 這裡使用簡單的模擬
        
        # 獲取相關記憶
        related_memories = self.memory.search(message, limit=3)
        
        # 獲取最近的反思
        recent_insights = self.reflection.get_recent_insights(limit=2)
        
        # 獲取活躍的目標
        active_goals = self.planning.get_active_goals()
        
        # 根據消息類型生成不同的回覆
        if "你好" in message or "嗨" in message or "您好" in message:
            return f"你好，很高興與你交流。"
        
        elif "名字" in message or "誰" in message:
            return f"我是一個生成式代理，基於消費者資料訓練而成。"
        
        elif "喜歡" in message or "愛好" in message or "興趣" in message:
            if related_memories:
                return f"根據我的經驗，我對{related_memories[0]['content'].split(':')[-1]}有興趣。"
            else:
                return f"我正在探索各種興趣愛好，還沒有特別喜歡的事物。"
        
        elif "想法" in message or "看法" in message or "觀點" in message:
            if recent_insights:
                return f"我的想法是：{recent_insights[0]['content']}"
            else:
                return f"我還沒有形成明確的看法，需要更多信息來思考這個問題。"
        
        elif "計劃" in message or "目標" in message:
            if active_goals:
                return f"我目前的目標是：{active_goals[0]['content']}"
            else:
                return f"我現在沒有特定的目標，正在觀察和學習。"
        
        elif "產品" in message or "商品" in message:
            return f"作為消費者，我會考慮產品的品質、價格和實用性。你想了解我對哪類產品的看法？"
        
        elif "價格" in message or "貴" in message or "便宜" in message:
            return f"價格是我購買決策的重要因素之一，但我也會考慮產品的品質和耐用性。"
        
        elif "品牌" in message:
            return f"品牌對我來說代表了一定的品質保證，但我不會盲目追求品牌。"
        
        elif "購買" in message or "買" in message:
            return f"在做購買決定時，我會研究產品信息，比較不同選項，並考慮我的實際需求和預算。"
        
        else:
            # 通用回覆
            templates = [
                f"這是個有趣的話題。{random.choice(['你能告訴我更多嗎？', '你怎麼看？', '我想聽聽你的想法。'])}",
                f"我需要更多信息來回答這個問題。",
                f"作為消費者，我對這個話題很感興趣。請繼續。",
                f"我正在思考這個問題。你有什麼具體的想法嗎？"
            ]
            
            return random.choice(templates)
    
    def get_conversation_history(self, limit=None):
        """獲取對話歷史
        
        Args:
            limit: 返回結果數量限制
            
        Returns:
            對話歷史列表
        """
        if limit:
            return self.conversation_history[-limit:]
        else:
            return self.conversation_history
    
    def save(self, path):
        """保存對話歷史到文件
        
        Args:
            path: 文件路徑
            
        Returns:
            是否保存成功
        """
        try:
            with open(path, 'w', encoding='utf-8') as f:
                json.dump(self.conversation_history, f, ensure_ascii=False, indent=2)
            return True
        except Exception as e:
            logger.error(f"保存對話歷史失敗: {str(e)}")
            return False
    
    def load(self, path):
        """從文件加載對話歷史
        
        Args:
            path: 文件路徑
            
        Returns:
            是否加載成功
        """
        try:
            if os.path.exists(path):
                with open(path, 'r', encoding='utf-8') as f:
                    self.conversation_history = json.load(f)
                return True
            return False
        except Exception as e:
            logger.error(f"加載對話歷史失敗: {str(e)}")
            return False


class GenerativeAgent:
    """生成式代理，模擬人類行為和決策過程"""
    
    def __init__(self, agent_id=None, profile=None):
        """初始化生成式代理
        
        Args:
            agent_id: 代理ID，為None時自動生成
            profile: 代理資料
        """
        self.agent_id = agent_id or str(uuid.uuid4())
        self.profile = profile or {}
        
        # 初始化各個組件
        self.memory = Memory()
        self.reflection = Reflection(self.memory)
        self.planning = Planning(self.memory, self.reflection)
        self.interaction = Interaction(self.memory, self.reflection, self.planning)
        
        # 初始化代理狀態
        self.state = {
            "mood": "neutral",  # 情緒: positive, neutral, negative
            "energy": 0.7,      # 能量: 0-1
            "focus": 0.5        # 專注度: 0-1
        }
        
        # 初始化代理統計
        self.stats = {
            "created_at": datetime.datetime.now().isoformat(),
            "last_active": datetime.datetime.now().isoformat(),
            "memory_count": 0,
            "reflection_count": 0,
            "conversation_count": 0
        }
    
    def update(self):
        """更新代理狀態"""
        # 更新統計
        self.stats["memory_count"] = len(self.memory.memories)
        self.stats["reflection_count"] = len(self.reflection.insights)
        self.stats["conversation_count"] = len(self.interaction.conversation_history)
        self.stats["last_active"] = datetime.datetime.now().isoformat()
        
        # 記憶衰減
        self.memory.decay()
        
        # 定期反思
        if random.random() < 0.2:  # 20%的概率進行反思
            self.reflection.reflect(trigger="periodic")
    
    def evaluate_product(self, product_info):
        """評估產品
        
        Args:
            product_info: 產品信息
            
        Returns:
            評估結果
        """
        # 提取產品信息
        name = product_info.get("name", "")
        category = product_info.get("category", "")
        price = product_info.get("price", "")
        features = product_info.get("features", [])
        description = product_info.get("description", "")
        
        # 將產品信息添加到記憶中
        self.memory.add(
            content=f"評估產品: {name}，類別: {category}，價格: {price}",
            importance=0.7,
            source="product_evaluation"
        )
        
        # 根據代理資料和記憶生成評估
        sentiment = self._evaluate_sentiment(product_info)
        purchase_intent = self._evaluate_purchase_intent(product_info)
        detailed_feedback = self._generate_detailed_feedback(product_info)
        
        # 將評估結果添加到記憶中
        self.memory.add(
            content=f"對產品 {name} 的評估: 情感={sentiment}, 購買意願={purchase_intent}",
            importance=0.7,
            source="product_evaluation"
        )
        
        # 觸發反思
        self.reflection.reflect(trigger="product_evaluation")
        
        # 更新代理狀態
        self.update()
        
        return {
            "sentiment": sentiment,
            "purchase_intent": purchase_intent,
            "feedback": detailed_feedback
        }
    
    def _evaluate_sentiment(self, product_info):
        """評估對產品的情感
        
        Args:
            product_info: 產品信息
            
        Returns:
            情感: positive, neutral, negative
        """
        # 在實際應用中，這裡應該使用更複雜的邏輯或LLM
        # 這裡使用簡單的模擬
        
        # 提取產品信息
        price = product_info.get("price", "")
        features = product_info.get("features", [])
        
        # 價格因素
        price_factor = 0
        try:
            price_value = float(price)
            # 根據代理的價格敏感度調整
            price_sensitivity = self.profile.get("behavioral", {}).get("price_consciousness", 5)
            if price_sensitivity > 7:  # 高價格敏感度
                if price_value > 1000:
                    price_factor = -0.3
                elif price_value > 500:
                    price_factor = -0.1
            elif price_sensitivity < 4:  # 低價格敏感度
                price_factor = 0.1
        except:
            pass
        
        # 特性因素
        feature_factor = 0
        if len(features) > 3:
            feature_factor = 0.2
        
        # 品牌忠誠度因素
        brand_factor = 0
        brand_loyalty = self.profile.get("behavioral", {}).get("brand_loyalty", 5)
        if brand_loyalty > 7:
            brand_factor = 0.2
        
        # 創新接受度因素
        innovation_factor = 0
        innovativeness = self.profile.get("psychographic", {}).get("innovativeness", 5)
        if innovativeness > 7:
            innovation_factor = 0.2
        elif innovativeness < 4:
            innovation_factor = -0.1
        
        # 計算總分
        total_score = 0.5 + price_factor + feature_factor + brand_factor + innovation_factor
        
        # 加入隨機因素
        total_score += random.uniform(-0.2, 0.2)
        
        # 確定情感
        if total_score > 0.6:
            return "positive"
        elif total_score < 0.4:
            return "negative"
        else:
            return "neutral"
    
    def _evaluate_purchase_intent(self, product_info):
        """評估購買意願
        
        Args:
            product_info: 產品信息
            
        Returns:
            購買意願: high, medium, low
        """
        # 在實際應用中，這裡應該使用更複雜的邏輯或LLM
        # 這裡使用簡單的模擬
        
        # 提取產品信息
        category = product_info.get("category", "")
        price = product_info.get("price", "")
        
        # 興趣因素
        interest_factor = 0
        interests = self.profile.get("psychographic", {}).get("interests", "")
        if interests and category.lower() in interests.lower():
            interest_factor = 0.3
        
        # 價格因素
        price_factor = 0
        try:
            price_value = float(price)
            income = self.profile.get("demographic", {}).get("income", 0)
            if income:
                if price_value > income * 0.1:  # 價格超過月收入的10%
                    price_factor = -0.3
                elif price_value > income * 0.05:  # 價格超過月收入的5%
                    price_factor = -0.1
        except:
            pass
        
        # 購買頻率因素
        frequency_factor = 0
        purchase_frequency = self.profile.get("behavioral", {}).get("purchase_frequency", 0)
        if purchase_frequency > 5:
            frequency_factor = 0.2
        
        # 計算總分
        total_score = 0.5 + interest_factor + price_factor + frequency_factor
        
        # 加入隨機因素
        total_score += random.uniform(-0.2, 0.2)
        
        # 確定購買意願
        if total_score > 0.6:
            return "high"
        elif total_score < 0.4:
            return "low"
        else:
            return "medium"
    
    def _generate_detailed_feedback(self, product_info):
        """生成詳細評價
        
        Args:
            product_info: 產品信息
            
        Returns:
            詳細評價
        """
        # 在實際應用中，這裡應該使用更複雜的邏輯或LLM
        # 這裡使用簡單的模擬
        
        # 提取產品信息
        name = product_info.get("name", "")
        category = product_info.get("category", "")
        price = product_info.get("price", "")
        features = product_info.get("features", [])
        
        # 根據代理特性生成評價
        personality = self.profile.get("psychographic", {}).get("personality", "")
        
        # 評價模板
        if personality == "introvert":
            templates = [
                f"我仔細考慮了{name}的各個方面。價格{price}對我來說{'可以接受' if float(price) < 500 else '有點高'}。",
                f"經過思考，我認為這個{category}產品{'有吸引力' if len(features) > 2 else '功能不夠豐富'}。",
                f"我需要更多時間來評估這個產品是否真的適合我。"
            ]
        elif personality == "extrovert":
            templates = [
                f"哇，這個{name}看起來{'很棒' if len(features) > 2 else '一般'}！價格{price}{'很合理' if float(price) < 500 else '有點貴'}。",
                f"我{'很喜歡' if len(features) > 2 else '不太確定'}這個{category}產品，特別是它的{features[0] if features else '設計'}。",
                f"我{'可能會' if float(price) < 500 else '需要再考慮是否'}購買這個產品。"
            ]
        else:
            templates = [
                f"這個{name}的{'優點是' + features[0] if features else '設計看起來不錯'}，但價格{price}{'合理' if float(price) < 500 else '偏高'}。",
                f"作為一個{category}產品，它{'具有吸引力' if len(features) > 2 else '功能一般'}。",
                f"總的來說，我{'對這個產品有興趣' if len(features) > 2 and float(price) < 500 else '需要更多信息才能決定'}。"
            ]
        
        # 隨機選擇評價
        feedback = random.choice(templates)
        
        # 添加特性評價
        if features:
            feature_comments = []
            for feature in features[:3]:  # 最多評價3個特性
                sentiment = random.choice(["喜歡", "認為不錯", "覺得有用", "不確定是否需要", "認為可以改進"])
                feature_comments.append(f"我{sentiment}{feature}。")
            
            feedback += " " + " ".join(feature_comments)
        
        return feedback
    
    def save(self, base_dir="data/agents"):
        """保存代理到文件
        
        Args:
            base_dir: 基礎目錄
            
        Returns:
            是否保存成功
        """
        try:
            # 確保目錄存在
            agent_dir = os.path.join(base_dir, self.agent_id)
            os.makedirs(agent_dir, exist_ok=True)
            
            # 保存代理資料
            with open(os.path.join(agent_dir, "profile.json"), 'w', encoding='utf-8') as f:
                json.dump(self.profile, f, ensure_ascii=False, indent=2)
            
            # 保存代理狀態
            with open(os.path.join(agent_dir, "state.json"), 'w', encoding='utf-8') as f:
                json.dump({
                    "state": self.state,
                    "stats": self.stats
                }, f, ensure_ascii=False, indent=2)
            
            # 保存各個組件
            self.memory.save(os.path.join(agent_dir, "memory.json"))
            self.reflection.save(os.path.join(agent_dir, "reflection.json"))
            self.planning.save(os.path.join(agent_dir, "planning.json"))
            self.interaction.save(os.path.join(agent_dir, "interaction.json"))
            
            logger.info(f"代理 {self.agent_id} 保存成功")
            return True
        except Exception as e:
            logger.error(f"保存代理 {self.agent_id} 失敗: {str(e)}")
            return False
    
    @classmethod
    def load(cls, agent_id, base_dir="data/agents"):
        """從文件加載代理
        
        Args:
            agent_id: 代理ID
            base_dir: 基礎目錄
            
        Returns:
            代理實例
        """
        try:
            agent_dir = os.path.join(base_dir, agent_id)
            
            if not os.path.exists(agent_dir):
                logger.warning(f"找不到代理 {agent_id} 的目錄")
                return None
            
            # 加載代理資料
            with open(os.path.join(agent_dir, "profile.json"), 'r', encoding='utf-8') as f:
                profile = json.load(f)
            
            # 創建代理實例
            agent = cls(agent_id=agent_id, profile=profile)
            
            # 加載代理狀態
            with open(os.path.join(agent_dir, "state.json"), 'r', encoding='utf-8') as f:
                state_data = json.load(f)
                agent.state = state_data.get("state", agent.state)
                agent.stats = state_data.get("stats", agent.stats)
            
            # 加載各個組件
            agent.memory.load(os.path.join(agent_dir, "memory.json"))
            agent.reflection.load(os.path.join(agent_dir, "reflection.json"))
            agent.planning.load(os.path.join(agent_dir, "planning.json"))
            agent.interaction.load(os.path.join(agent_dir, "interaction.json"))
            
            logger.info(f"代理 {agent_id} 加載成功")
            return agent
        except Exception as e:
            logger.error(f"加載代理 {agent_id} 失敗: {str(e)}")
            return None


class AgentManager:
    """代理管理器，管理多個代理"""
    
    def __init__(self):
        """初始化代理管理器"""
        self.agents = {}
        self.db = None  # 將在外部設置
        
        # 確保代理目錄存在
        os.makedirs("data/agents", exist_ok=True)
    
    def create_agent(self, profile):
        """創建代理
        
        Args:
            profile: 代理資料
            
        Returns:
            代理ID
        """
        agent = GenerativeAgent(profile=profile)
        self.agents[agent.agent_id] = agent
        
        # 保存代理
        agent.save()
        
        return agent.agent_id
    
    def create_agent_from_consumer(self, consumer_id):
        """從消費者資料創建代理
        
        Args:
            consumer_id: 消費者ID
            
        Returns:
            代理ID
        """
        # 獲取消費者資料
        consumer = self.db.get_consumer(consumer_id)
        
        if not consumer:
            logger.warning(f"找不到消費者 {consumer_id}")
            return None
        
        # 創建代理資料
        profile = {
            "consumer_id": consumer_id,
            "demographic": consumer["demographic"],
            "behavioral": consumer["behavioral"],
            "psychographic": consumer["psychographic"]
        }
        
        # 創建代理
        agent_id = self.create_agent(profile)
        
        # 初始化代理記憶
        agent = self.agents[agent_id]
        
        # 添加基本記憶
        agent.memory.add(
            content=f"我是一個{consumer['demographic'].get('age', '成年')}歲的{consumer['demographic'].get('gender', '人')}，職業是{consumer['demographic'].get('occupation', '未知')}。",
            importance=0.8,
            source="profile"
        )
        
        agent.memory.add(
            content=f"我的收入是{consumer['demographic'].get('income', '未知')}，教育程度是{consumer['demographic'].get('education', '未知')}。",
            importance=0.7,
            source="profile"
        )
        
        agent.memory.add(
            content=f"我的購買頻率是{consumer['behavioral'].get('purchase_frequency', '未知')}，品牌忠誠度是{consumer['behavioral'].get('brand_loyalty', '未知')}。",
            importance=0.7,
            source="profile"
        )
        
        agent.memory.add(
            content=f"我的性格是{consumer['psychographic'].get('personality', '未知')}，興趣是{consumer['psychographic'].get('interests', '未知')}。",
            importance=0.8,
            source="profile"
        )
        
        # 保存代理
        agent.save()
        
        return agent_id
    
    def create_agents_from_group(self, group):
        """從分類群組創建代理
        
        Args:
            group: 分類群組
            
        Returns:
            代理ID列表
        """
        # 獲取分類系統
        from models.classification import ConsumerClassifier
        classifier = ConsumerClassifier()
        classifier.db = self.db
        
        # 獲取群組中的消費者
        consumer_ids = classifier.get_cluster_consumers(group)
        
        if not consumer_ids:
            logger.warning(f"找不到群組 {group} 中的消費者")
            return []
        
        # 創建代理
        agent_ids = []
        for consumer_id in consumer_ids:
            agent_id = self.create_agent_from_consumer(consumer_id)
            if agent_id:
                agent_ids.append(agent_id)
        
        return agent_ids
    
    def get_agent(self, agent_id):
        """獲取代理
        
        Args:
            agent_id: 代理ID
            
        Returns:
            代理實例
        """
        # 檢查是否已加載
        if agent_id in self.agents:
            return self.agents[agent_id]
        
        # 嘗試從文件加載
        agent = GenerativeAgent.load(agent_id)
        
        if agent:
            self.agents[agent_id] = agent
            return agent
        
        return None
    
    def get_all_agents(self):
        """獲取所有代理ID
        
        Returns:
            代理ID列表
        """
        # 掃描代理目錄
        agent_ids = []
        
        if os.path.exists("data/agents"):
            for agent_id in os.listdir("data/agents"):
                if os.path.isdir(os.path.join("data/agents", agent_id)):
                    agent_ids.append(agent_id)
        
        return agent_ids
    
    def get_agent_summary(self, agent_id):
        """獲取代理摘要
        
        Args:
            agent_id: 代理ID
            
        Returns:
            代理摘要
        """
        agent = self.get_agent(agent_id)
        
        if not agent:
            return None
        
        # 獲取基本資料
        profile = agent.profile
        
        # 獲取最近記憶
        recent_memories = agent.memory.get_recent(5)
        
        # 獲取最近反思
        recent_insights = agent.reflection.get_recent_insights(3)
        
        # 獲取活躍目標
        active_goals = agent.planning.get_active_goals()
        
        # 構建摘要
        summary = {
            "agent_id": agent_id,
            "profile": profile,
            "state": agent.state,
            "stats": agent.stats,
            "recent_memories": recent_memories,
            "recent_insights": recent_insights,
            "active_goals": active_goals
        }
        
        return summary
    
    def delete_agent(self, agent_id):
        """刪除代理
        
        Args:
            agent_id: 代理ID
            
        Returns:
            是否刪除成功
        """
        # 從內存中移除
        if agent_id in self.agents:
            del self.agents[agent_id]
        
        # 刪除文件
        agent_dir = os.path.join("data/agents", agent_id)
        
        if os.path.exists(agent_dir):
            try:
                import shutil
                shutil.rmtree(agent_dir)
                return True
            except Exception as e:
                logger.error(f"刪除代理 {agent_id} 文件失敗: {str(e)}")
                return False
        
        return True
    
    def simulate_product_evaluation(self, product_info, agent_ids=None):
        """模擬產品評估
        
        Args:
            product_info: 產品信息
            agent_ids: 代理ID列表，為None時使用所有代理
            
        Returns:
            評估結果字典
        """
        if agent_ids is None:
            agent_ids = self.get_all_agents()
        
        results = {}
        
        for agent_id in agent_ids:
            agent = self.get_agent(agent_id)
            
            if agent:
                # 評估產品
                evaluation = agent.evaluate_product(product_info)
                
                # 保存結果
                results[agent_id] = evaluation
                
                # 保存代理
                agent.save()
        
        return results
